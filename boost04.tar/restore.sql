--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE boost04;
--
-- Name: boost04; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE boost04 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE boost04 OWNER TO postgres;

\connect boost04

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE boost04; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE boost04 IS 'lorem ipsum';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: class101; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class101 (
    oid bigint NOT NULL,
    class_name character varying(50) NOT NULL,
    gpa double precision DEFAULT 0.0 NOT NULL
);


ALTER TABLE public.class101 OWNER TO postgres;

--
-- Name: class101_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.class101 ALTER COLUMN oid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.class101_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: student_classes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_classes (
    national_id bigint NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    city character varying NOT NULL,
    street character varying NOT NULL,
    country character varying NOT NULL,
    country_code integer NOT NULL,
    telephone_number character varying NOT NULL,
    course_id integer,
    course_name character varying,
    attandence_year integer,
    grade double precision
);


ALTER TABLE public.student_classes OWNER TO postgres;

--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    oid bigint NOT NULL,
    name character varying NOT NULL,
    last_name character varying NOT NULL,
    middle_name character varying,
    registration_number integer NOT NULL
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_oid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_oid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.students_oid_seq OWNER TO postgres;

--
-- Name: students_oid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_oid_seq OWNED BY public.students.oid;


--
-- Name: students oid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN oid SET DEFAULT nextval('public.students_oid_seq'::regclass);


--
-- Data for Name: class101; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class101 (oid, class_name, gpa) FROM stdin;
\.
COPY public.class101 (oid, class_name, gpa) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: student_classes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_classes (national_id, first_name, last_name, city, street, country, country_code, telephone_number, course_id, course_name, attandence_year, grade) FROM stdin;
\.
COPY public.student_classes (national_id, first_name, last_name, city, street, country, country_code, telephone_number, course_id, course_name, attandence_year, grade) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (oid, name, last_name, middle_name, registration_number) FROM stdin;
\.
COPY public.students (oid, name, last_name, middle_name, registration_number) FROM '$$PATH$$/3339.dat';

--
-- Name: class101_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.class101_oid_seq', 6, true);


--
-- Name: students_oid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_oid_seq', 1, false);


--
-- Name: class101 oid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class101
    ADD CONSTRAINT oid PRIMARY KEY (oid);


--
-- Name: students primary_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT primary_key PRIMARY KEY (oid);


--
-- Name: student_classes student_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_classes
    ADD CONSTRAINT student_classes_pkey PRIMARY KEY (national_id);


--
-- Name: class101 unique_class_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class101
    ADD CONSTRAINT unique_class_name UNIQUE (class_name);


--
-- Name: students unique_registration_number; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT unique_registration_number UNIQUE (registration_number);


--
-- Name: DATABASE boost04; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON DATABASE boost04 FROM postgres;
GRANT CREATE,CONNECT ON DATABASE boost04 TO postgres;
GRANT TEMPORARY ON DATABASE boost04 TO postgres WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

